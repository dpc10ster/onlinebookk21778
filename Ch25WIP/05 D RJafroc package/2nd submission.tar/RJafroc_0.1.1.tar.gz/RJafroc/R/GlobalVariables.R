RJafrocEnv <- new.env()
assign("UNINITIALIZED", -Inf, envir = RJafrocEnv)

# assign("minZeta", -30, envir = RJafrocEnv)
# assign("maxZeta", 30, envir = RJafrocEnv)
# 
# assign("minLambda", 0.01, envir = RJafrocEnv)
# assign("maxLambda", 20, envir = RJafrocEnv)
# 
# assign("minBeta", 0.01, envir = RJafrocEnv)
# assign("maxBeta", 20, envir = RJafrocEnv)
# 
# assign("minMu", 0.01, envir = RJafrocEnv)
# assign("maxMu", 10, envir = RJafrocEnv) 
